<?php
/*
 * Copyright (c) SocialLOFT LLC
 * mooSocial - The Web 2.0 Social Network Software
 * @website: http://www.moosocial.com
 * @author: mooSocial
 * @license: https://moosocial.com/license/
 */
class ThemeDefaultHelper extends AppHelper {
    public $theme_enable_appearance = true;

    public function geImagePath($image){
        return '../../../uploads/theme/'.$image;
    }

    public function renderCSS($class, $style, $media = ''){
        /*$class = array(
            'A', 'B', 'C'
        );
        $style = array(
            'background-image' => '',
            'background-repeat' => '',
            'background-position' => '',
            'background-size' => '',
            'background-color' => '',
            'background-attachment' => '',
            'color' => '',
            'border-color' => ''
        );*/

        $class_str = '';
        $style_str = '';

        if(is_array($class)){
            if(count($class) > 0){
                foreach ($class As $c){
                    if($class_str != ''){
                        $class_str .= ', '.$c;
                    }else{
                        $class_str .= $c;
                    }
                }
            }
        }else{
            $class_str = $class;
        }

        if(is_array($style)){
            if(count($style) > 0){
                foreach ($style As $k => $v){
                    if(!empty($v)){
                        if($k == 'background-image'){
                            if($v == 'none'){
                                $vv = $v;
                            }else{
                                $vv = 'url('.$this->geImagePath($v).')';
                            }
                        }elseif ($k == 'background-image-2'){
                            $k = 'background-image';
                            $vv = $v;
                        }
                        else{
                            $vv = $v;
                        }
                        $style_str .= $k.': '.$vv.';';
                    }
                }
            }
        }else{
            $style_str = $style;
        }

        if(($class_str != '') && ($style_str != '')){
            if($media != ''){
                return $media . '{' . $class_str .'{'.$style_str.'}' . '}';
            }
            return $class_str .'{'.$style_str.'}';
        }
        return '';
    }

    public function cssValue($key,$cssArray, $defaultValue = ''){
        return (!empty($cssArray[$key]['value'])) ? $cssArray[$key]['value'] : $defaultValue;
    }

    public function theme_setting_css($cssArray){
        $content = '';
        if(!empty($cssArray)){
            /* Body --------------------------------------------------------------------------------------------------------- */

            $content .= $this->renderCSS(array(
                'body.default-body'
            ), array(
                'background-image' => $this->cssValue('page_background_image', $cssArray),
                'background-position' => $this->cssValue('page_background_position', $cssArray),
                'background-repeat' => $this->cssValue('page_background_repeat', $cssArray),
                'background-size' => $this->cssValue('page_background_size', $cssArray),
                'background-color' => $this->cssValue('page_background_color', $cssArray),
                'background-attachment' => $this->cssValue('page_background_attachment', $cssArray),
                'color' => $this->cssValue('page_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.core-breadcrumb-warp .breadcrumb li a', '.breadcrumb > li + li:before'
            ), array(
                'color' => $this->cssValue('page_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                'a'
            ), array(
                'color' => $this->cssValue('page_link_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'a:hover', 'a:focus', 'a:active'
            ), array(
                'color' => $this->cssValue('page_active_link_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.box2.bar-content-warp', '.feed-entry-item', '.activity_item', '.activity_feed_content_text .share-content', '.profile-header', '.profile-menu', '.registration-page', '.registration-page .register_main_form', '.section-page .section-page-header', '.close-network-signup', '.login-page-content'
            ), array(
                'border-color' => $this->cssValue('page_border_color', $cssArray)
            ));

            /* Header --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.header-section'
            ), array(
                'background-image' => $this->cssValue('page_header_background_image', $cssArray),
                'background-position' => $this->cssValue('page_header_background_position', $cssArray),
                'background-repeat' => $this->cssValue('page_header_background_repeat', $cssArray),
                'background-size' => $this->cssValue('page_header_background_size', $cssArray),
                'background-color' => $this->cssValue('page_header_background_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.header-section'
            ), array(
                'background-color' => $this->cssValue('page_header_top_background_color', $cssArray)
            ), '@media (max-width: 991px)');

            $content .= $this->renderCSS(array(
                '.mobile-logo'
            ), array(
                'background-color' => $this->cssValue('page_header_background_color', $cssArray)
            ));

            if(empty($cssArray['page_header_background_image']['value'])) {
                $content .= $this->renderCSS(array(
                    '.header-bg', '.documentScrolling .header-section'
                ), array(
                    'background-color' => $this->cssValue('page_header_top_background_color', $cssArray)
                ));
            }

            $content .= $this->renderCSS(array(
                '.notify_content > a .btn-group-icon', '.global-search-header .global-search-btn-mobile .global-search-btn-icon', '.main-menu-section .main-menu-toggle', '.menu_acc_content .dropdown-user-box', '.login-popup-group .dropdown-popup-toggle .dropdown-user-arrow'
            ), array(
                'color' => $this->cssValue('page_header_icons_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu-section .main-menu-toggle .main-menu-toggle-text', '.menu_acc_content', '.login-popup-group .dropdown-popup-toggle .dropdown-user-avatar'
            ), array(
                'border-color' => $this->cssValue('page_header_icons_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notify_content > a.hasNotify .btn-group-icon'
            ), array(
                'color' => $this->cssValue('page_header_icons_active_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.header-section .header-bg'
            ), array(
                'border-color' => $this->cssValue('page_header_border_color', $cssArray)
            ));

            /* User --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.moocore_tooltip_link', '.core-list-item .moocore_tooltip_link', '.feed-entry-item .activity_author .moocore_tooltip_link', '.activity_item .activity_item_title', '.comment_lists .comment-item .comment-user-name a'
            ), array(
                'color' => $this->cssValue('page_user_name_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu_acc_content .dropdown-menu'
            ), array(
                'background-color' => $this->cssValue('page_user_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu_acc_content .arr-down'
            ), array(
                'border-color' => (!empty($cssArray['page_user_dropdown_background_color']['value'])) ? 'transparent transparent '.$cssArray['page_user_dropdown_background_color']['value'].' transparent' : ''
            ));
            $content .= $this->renderCSS(array(
                '.menu_acc_content .dropdown-menu > li > a'
            ), array(
                'color' => $this->cssValue('page_user_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu_acc_content .dropdown-menu > li > a:hover, .menu_acc_content .dropdown-menu > li > a:focus'
            ), array(
                'background-color' => $this->cssValue('page_user_dropdown_hover_background_color', $cssArray),
                'color' => $this->cssValue('page_user_dropdown_hover_text_color', $cssArray)
            ));

            /* List Items --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.core-list-item a:not(.btn)'
            ), array(
                'color' => $this->cssValue('page_list_item_link_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-list-item a.core-item-title', '.user-lists .user-list-item .user-item-name a.moocore_tooltip_link'
            ), array(
                'color' => $this->cssValue('page_list_item_title_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-item-like_count'
            ), array(
                'color' => $this->cssValue('page_list_item_count_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-item-date', '.core-list-item .core-item-privacy', '.user-lists .user-list-item .user-item-date'
            ), array(
                'color' => $this->cssValue('page_list_item_date_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-item-description', '.core-list-idx', '.user-lists .user-list-item .user-item-holder', '.user-lists .user-list-item .user-item-holder a'
            ), array(
                'color' => $this->cssValue('page_list_item_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-pin-icon'
            ), array(
                'color' => $this->cssValue('page_list_item_pin_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.list_option button'
            ), array(
                'color' => $this->cssValue('page_list_item_dropdown_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.grid-list-bar .gl-item'
            ), array(
                'background-color' => $this->cssValue('page_list_item_gridlist_background_color', $cssArray),
                'color' => $this->cssValue('page_list_item_gridlist_icon_color', $cssArray),
                'border-color' => $this->cssValue('page_list_item_gridlist_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.grid-list-bar .gl-item.active'
            ), array(
                'background-color' => $this->cssValue('page_list_item_gridlist_active_background_color', $cssArray),
                'color' => $this->cssValue('page_list_item_gridlist_icon_active_color', $cssArray),
                'border-color' => $this->cssValue('page_list_item_gridlist_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core-lists.list-view .core-list-item', '.user-lists .user-list-item .user-item-warp', '.core-lists.grid-view .core-list-item .core-item-warp', '.table-compare table td', '.compare-item .content.plan-recommend', '.box-user-list .box-user-item .box-user-item-warp', '.album-box-lists .album-box-item .album-box-item-warp', '.core-lists.grid-view > .core-list-item .core-item-action',
                '.compare-item .content', '.album-lists .album-list-item .album-item-warp'
            ), array(
                'border-color' => $this->cssValue('page_list_item_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box-user-list .box-user-item .box-user-item-warp'
            ), array(
                'background-color' => $this->cssValue('page_list_item_border_color', $cssArray),
                'border-color' => $this->cssValue('page_list_item_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.view-more a', '.view-more a:hover', '.view-more a:active', '.view-more a:focus',
                '.view-more-no-ajax a', '.view-more-no-ajax a:hover', '.view-more-no-ajax a:active', '.view-more-no-ajax a:focus'
            ), array(
                'background-color' => $this->cssValue('button_viewmore_background_color', $cssArray),
                'color' => $this->cssValue('button_viewmore_text_color', $cssArray),
                'border-color' => $this->cssValue('button_viewmore_border_color', $cssArray)
            ));

            /* Like Section --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.like-action .act-item .act-item-symbol .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_like_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.like-action .act-item .act-item-text .act-item-txt'
            ), array(
                'color' => $this->cssValue('page_like_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.like-action .act-item .act-item-symbol.active .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_like_icon_active_color', $cssArray)
            ));

            /* Footer --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '#footer'
            ), array(
                'background-image' => $this->cssValue('page_footer_background_image', $cssArray),
                'background-position' => $this->cssValue('page_footer_background_position', $cssArray),
                'background-repeat' => $this->cssValue('page_footer_background_repeat', $cssArray),
                'background-size' => $this->cssValue('page_footer_background_size', $cssArray),
                'background-color' => $this->cssValue('page_footer_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#footer .footer-menu-top'
            ), array(
                'border-color' => $this->cssValue('page_footer_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#footer', '#footer .copyright'
            ), array(
                'color' => $this->cssValue('page_footer_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#footer .core_menu li .core-menu-link'
            ), array(
                'color' => $this->cssValue('page_footer_text_link_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#footer ul.core_menu .main-menu-sub li .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_footer_dropdown_background_color', $cssArray),
                'color' => $this->cssValue('page_footer_dropdown_text_link_color', $cssArray)
            ));

            /* Modal --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.modal .modal-content', '#page_share-ajax_share .share-section + .modal-footer'
            ), array(
                'background-color' => $this->cssValue('page_modal_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.modal .modal-content', '.modal .close', '.modal-footer .share-content-action .userTagged-btn'
            ), array(
                'color' => $this->cssValue('page_modal_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.modal-footer', '.modal .modal-header', '.modal .modal-footer'
            ), array(
                'border-color' => $this->cssValue('page_modal_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-modal_close'
            ), array(
                'background-color' => $this->cssValue('page_modal_button_close_background_color', $cssArray),
                'border-color' => $this->cssValue('page_modal_button_close_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-modal_close', '.btn-modal_close:hover', '.btn-modal_close:active', '.btn-modal_close:focus'
            ), array(
                'color' => $this->cssValue('page_modal_button_close_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-modal_save', '.btn-modal_save:hover', '.btn-modal_save:active', '.btn-modal_save:focus'
            ), array(
                'background-color' => $this->cssValue('page_modal_button_ok_background_color', $cssArray),
                'border-color' => $this->cssValue('page_modal_button_ok_border_color', $cssArray),
                'color' => $this->cssValue('page_modal_button_ok_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-modal_delete', '.btn-modal_delete:hover', '.btn-modal_delete:active', '.btn-modal_delete:focus'
            ), array(
                'background-color' => $this->cssValue('page_modal_button_delete_background_color', $cssArray),
                'border-color' => $this->cssValue('page_modal_button_delete_border_color', $cssArray),
                'color' => $this->cssValue('page_modal_button_delete_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.photo-tags .photoDetailTags'
            ), array(
                'background-color' => $this->cssValue('photo_theater_tag_button_background_color', $cssArray),
                'border-color' => $this->cssValue('photo_theater_tag_button_border_color', $cssArray),
                'color' => $this->cssValue('photo_theater_tag_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.photo-tags .photoDetailTags a', '.photo-tags .photoDetailTags .photoDetailRemoveTags .photo-remove-tag-icon'
            ), array(
                'color' => $this->cssValue('photo_theater_tag_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.photo-tags .photoDetailTags a:hover', '.photo-tags .photoDetailTags a:active', '.photo-tags .photoDetailTags a:focus'
            ), array(
                'color' => $this->cssValue('photo_theater_tag_button_hover_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#tag-input'
            ), array(
                'background-color' => $this->cssValue('photo_theater_tag_box_background_color', $cssArray),
                'color' => $this->cssValue('photo_theater_tag_box_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#tag-target'
            ), array(
                'border-color' => $this->cssValue('photo_theater_tag_box_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#tag-input .tag_friends_list a'
            ), array(
                'color' => $this->cssValue('photo_theater_tag_box_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#tag-input input[type="text"]'
            ), array(
                'background-color' => $this->cssValue('photo_theater_tag_box_background_color', $cssArray),
                'color' => $this->cssValue('photo_theater_tag_box_text_color', $cssArray),
                'border-color' => $this->cssValue('photo_theater_tag_box_border_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '#tag-input .btn-primary', '#tag-input .btn-default'
            ), array(
                'background-color' => $this->cssValue('photo_theater_tag_box_button_background_color', $cssArray),
                'color' => $this->cssValue('photo_theater_tag_box_button_text_color', $cssArray),
                'border-color' => $this->cssValue('photo_theater_tag_box_button_border_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.hotspot span', '.hotspot:hover span', '.hotspothover span'
            ), array(
                'background-color' => $this->cssValue('photo_theater_tag_box_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.hotspot span:after'
            ), array(
                'border-color' => $this->cssValue('photo_theater_tag_box_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.hotspot span', '.hotspot span a'
            ), array(
                'color' => $this->cssValue('photo_theater_tag_box_text_color', $cssArray)
            ));


            /* Navigation --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.main-menu li.mobile-show-menu-child'
            ), array(
                'background-color' => $this->cssValue('page_navigation_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.documentScrolling .main-menu-section.main-menu-scrolling .main-menu-warp',
                '.main-menu-section .main-menu-warp',
            ), array(
                'background-color' => $this->cssValue('page_navigation_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu-section .main-menu-warp .main-menu-content'
            ), array(
                'background-color' => $this->cssValue('page_navigation_background_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                '.main-menu > li > .core-menu-link', '.main-menu > li > .main-menu-arrow', '.main-menu li.hasChild > .main-menu-arrow'
            ), array(
                'color' => $this->cssValue('page_navigation_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu > li > .core-menu-link.active', '.main-menu > li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_navigation_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu > li:hover > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_navigation_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu li.current:not(.mobile-show-menu-child) > .core-menu-link'
            ), array(
                'color' => $this->cssValue('page_navigation_active_text_color', $cssArray),
                'background-color' => $this->cssValue('page_navigation_active_background_color', $cssArray)
            ), '@media (max-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu li.current:not(.mobile-show-menu-child) > .main-menu-arrow'
            ), array(
                'color' => $this->cssValue('page_navigation_active_text_color', $cssArray)
            ), '@media (max-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu > li > .core-menu-link.active'
            ), array(
                'border-color' => $this->cssValue('page_navigation_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu > li > .core-menu-link.active', '.main-menu > li.current > .main-menu-arrow', '.main-menu > li.current > .core-menu-link', '.main-menu > li > .main-menu-arrow.active'
            ), array(
                'color' => $this->cssValue('page_navigation_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu > li:hover > .main-menu-arrow', '.main-menu > li:hover > .core-menu-link'
            ), array(
                'color' => $this->cssValue('page_navigation_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_navigation_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub li .core-menu-link', '.main-menu .main-menu-sub li .main-menu-arrow'
            ), array(
                'color' => $this->cssValue('page_navigation_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li > .core-menu-link', '.main-menu .main-menu-sub > li .main-menu-sub', '.main-menu .main-menu-sub > li > .core-menu-link.active'
            ), array(
                'border-color' => $this->cssValue('page_navigation_dropdown_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li > .core-menu-link.active', '.main-menu .main-menu-sub > li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_navigation_dropdown_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li:hover > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_navigation_dropdown_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li > .core-menu-link.active', '.main-menu .main-menu-sub > li.current > .core-menu-link', '.main-menu .main-menu-sub > li.current > .main-menu-arrow', '.main-menu .main-menu-sub > li > .main-menu-arrow.active'
            ), array(
                'color' => $this->cssValue('page_navigation_dropdown_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li:hover > .core-menu-link, .main-menu .main-menu-sub > li:hover > .main-menu-arrow'
            ), array(
                'color' => $this->cssValue('page_navigation_dropdown_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li.current > .core-menu-link'
            ), array(
                'border-color' => $this->cssValue('page_navigation_dropdown_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu .main-menu-sub > li:hover > .core-menu-link'
            ), array(
                'border-color' => $this->cssValue('page_navigation_dropdown_active_border_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.main-menu li > .main-sub-menu-back'
            ), array(
                'color' => $this->cssValue('page_navigation_back_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.main-menu li > .main-sub-menu-back'
            ), array(
                'border-color' => $this->cssValue('page_navigation_back_border_color', $cssArray)
            ));

            /* Sticky Menu --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.bar-action-floating', '.profile-scroll.profileScrolling .profile-scroll-main', '.profile-floating-menu .profile-menu', '.profile-floating-menu .profile-scroll .profile-menu'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-floating-menu .profile-menu', '.profile-floating-menu .profile-scroll .profile-menu'
            ), array(
                'background-color' =>$this->cssValue('page_stickymenu_background_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li > a', '.profileScrolling .profile-menu .horizontal-menu > li > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.current > a', '.profileScrolling .profile-menu .horizontal-menu > li.current > a'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.current > a', '.profileScrolling .profile-menu .horizontal-menu > li.current > a'
            ), array(
                'border-color' => $this->cssValue('page_stickymenu_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li:hover > a', '.profileScrolling .profile-menu .horizontal-menu > li:hover > a'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.current > a', '.profileScrolling .profile-menu .horizontal-menu > li.current > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li:hover > a', '.profileScrolling .profile-menu .horizontal-menu > li:hover > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_count_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_count_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_count_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.current > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li.current > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_count_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li:hover > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li:hover > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_count_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.current > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li.current > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_count_active_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_count_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li:hover > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu > li:hover > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_count_active_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_count_active_border_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li > a'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li.current > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li:hover > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li.current > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li:hover > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li > a', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li > a'
            ), array(
                'border-color' => $this->cssValue('page_stickymenu_dropdown_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li.horizontal-menu-open > .horizontal-menu-header::after', '.profileScrolling .profile-menu .horizontal-menu > li.horizontal-menu-open > .horizontal-menu-header::after'
            ), array(
                'border-bottom-color' => $this->cssValue('page_stickymenu_dropdown_arrow_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_count_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_count_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_dropdown_count_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_count_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_count_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_count_active_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_dropdown_count_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter', '.profileScrolling .profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_count_active_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_dropdown_count_active_border_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li > .horizontal-menu-sub', '.bar-action-floating .horizontal-menu > li > .horizontal-menu-close', '.profileScrolling .profile-menu .horizontal-menu > li > .horizontal-menu-sub', '.bar-action-floating .horizontal-menu > li > .horizontal-menu-close'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_dropdown_overlay_background_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                '.bar-action-floating .horizontal-menu > li > .horizontal-menu-close .horizontal-menu-close-icon', '.profileScrolling .profile-menu .horizontal-menu > li > .horizontal-menu-close .horizontal-menu-close-icon'
            ), array(
                'color' => $this->cssValue('page_stickymenu_dropdown_close_icon_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                '.btn-header_icon', '.btn-header_icon:hover', '.btn-header_icon:active', '.btn-header_icon.nice-select.open', '.btn-header_icon:focus'
            ), array(
                'color' => $this->cssValue('page_stickymenu_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .btn.box-btn', '.profileScrolling .btn.btn-profile', '.profileScrolling .btn-profile', '.profileScrolling .btn-dropdown .dropdown .dropdown-btn.btn-profile'
            ), array(
                'color' => $this->cssValue('page_stickymenu_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.bar-action-floating .btn-header_title', '.profileScrolling .btn.btn-profile', '.profileScrolling .btn-profile'
            ), array(
                'background-color' => $this->cssValue('page_stickymenu_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_stickymenu_button_border_color', $cssArray)
            ));

            /* Category Menu --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item .menu-list-link', '.menu-list .menu-list-item span.menu-list-header'
            ), array(
                'background-color' => $this->cssValue('page_category_menu_background_color', $cssArray),
                'color' => $this->cssValue('page_category_menu_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item.current > .menu-list-link', '.menu-list .menu-list-item ul.menu-list-dropdown .menu-list-sub-item.current > .menu-list-link', '.menu-list .menu-list-item:hover > span.menu-list-header', '.menu-list .menu-list-item:hover > .menu-list-link', '.menu-list .menu-list-item ul.menu-list-dropdown .menu-list-sub-item:hover > .menu-list-link'
            ), array(
                'background-color' => $this->cssValue('page_category_menu_active_background_color', $cssArray),
                'color' => $this->cssValue('page_category_menu_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item .menu-list-link .badge_counter', '.menu-list .menu-list-item span.menu-list-header .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_category_menu_counter_background_color', $cssArray),
                'border-color' => $this->cssValue('page_category_menu_counter_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item .menu-list-link .badge_counter', '.menu-list .menu-list-item span.menu-list-header .badge_counter'
            ), array(
                'color' => $this->cssValue('page_category_menu_counter_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item:hover > .menu-list-link > .badge_counter', '.menu-list .menu-list-item.current > .menu-list-link > .badge_counter', '.menu-list ul.menu-list-dropdown .menu-list-sub-item:hover .badge_counter', '.menu-list ul.menu-list-dropdown .menu-list-sub-item.current .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_category_menu_counter_active_background_color', $cssArray),
                'border-color' => $this->cssValue('page_category_menu_counter_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item:hover > .menu-list-link > .badge_counter', '.menu-list .menu-list-item.current > .menu-list-link > .badge_counter', '.menu-list ul.menu-list-dropdown .menu-list-sub-item:hover .badge_counter', '.menu-list ul.menu-list-dropdown .menu-list-sub-item.current .badge_counter'
            ), array(
                'color' => $this->cssValue('page_category_menu_counter_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item span.menu-list-header.header-arrow::after'
            ), array(
                'border-top-color' => $this->cssValue('page_category_menu_arrow_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list.menu-list-toggle .menu-list-item.open span.menu-list-header.header-arrow::after'
            ), array(
                'border-bottom-color' => $this->cssValue('page_category_menu_arrow_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list .menu-list-item:hover span.menu-list-header.header-arrow::after', '.menu-list .menu-list-item.current span.menu-list-header.header-arrow::after'
            ), array(
                'border-top-color' => $this->cssValue('page_category_menu_arrow_active_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.menu-list.menu-list-toggle .menu-list-item.open:hover span.menu-list-header.header-arrow::after', '.menu-list.menu-list-toggle .menu-list-item.open.current span.menu-list-header.header-arrow::after'
            ), array(
                'border-bottom-color' => $this->cssValue('page_category_menu_arrow_active_color', $cssArray)
            ));

            /* Menu Horizontal --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal', 'ul.core_widget_menu.horizontal > li > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal > li > .core-menu-link.active',
                'ul.core_widget_menu.horizontal > li:hover > .core-menu-link',
                'ul.core_widget_menu.horizontal > li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_active_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal .main-menu-sub li .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_dropdown_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_dropdown_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal .main-menu-sub li > .core-menu-link.active',
                'ul.core_widget_menu.horizontal .main-menu-sub li:hover > .core-menu-link',
                'ul.core_widget_menu.horizontal .main-menu-sub li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_dropdown_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            /*  -------- */
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal > li > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal > li > .core-menu-link.active'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_active_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_active_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal .main-menu-sub li .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_dropdown_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_dropdown_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.horizontal .main-menu-sub li > .core-menu-link.active'
            ), array(
                'background-color' => $this->cssValue('page_horizontal_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_horizontal_dropdown_active_text_color', $cssArray)
            ), '@media (max-width: 991px)');

            /* Menu Vertical --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical > li > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical > li > .core-menu-link.active',
                'ul.core_widget_menu.vertical > li:hover > .core-menu-link',
                'ul.core_widget_menu.vertical > li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_active_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical .main-menu-sub li .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_dropdown_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_dropdown_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical .main-menu-sub li > .core-menu-link.active',
                'ul.core_widget_menu.vertical .main-menu-sub li:hover > .core-menu-link',
                'ul.core_widget_menu.vertical .main-menu-sub li.current > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_dropdown_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            /*  -------- */
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical > li > .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical > li > .core-menu-link.active'
            ), array(
                'background-color' => $this->cssValue('page_vertical_active_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_active_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical .main-menu-sub li .core-menu-link'
            ), array(
                'background-color' => $this->cssValue('page_vertical_dropdown_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_dropdown_text_color', $cssArray)
            ), '@media (max-width: 991px)');
            $content .= $this->renderCSS(array(
                'ul.core_widget_menu.vertical .main-menu-sub li > .core-menu-link.active'
            ), array(
                'background-color' => $this->cssValue('page_vertical_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_vertical_dropdown_active_text_color', $cssArray)
            ), '@media (max-width: 991px)');

            /* Feed Header --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.feed_breadcrumb .feed_breadcrumb_title'
            ), array(
                'color' => $this->cssValue('page_feed_header_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed_breadcrumb .feed-type-list .feed-type-item'
            ), array(
                'color' => $this->cssValue('page_feed_type_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed_breadcrumb .feed-type-list .feed-type-item.current'
            ), array(
                'color' => $this->cssValue('page_feed_type_active_color', $cssArray)
            ));

            /* Status Box --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '#status_box', '.userTagging-userTagging .bootstrap-tagsinput'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#status_box', '.stt-action', '#userTagging-id-userTagging', '.userTagging-userTagging', '.form-feed-share #preview_link.activity_item', '.form-feed-review-main .form-feed-review-item', '#wall_photo_preview .photo-review-thumb', '.post-status-page-content .post-status-page-content-wrap #status_box .stt-action'
            ), array(
                'border-color' => $this->cssValue('page_statusbox_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#wall_photo_preview .addMoreImage .add-more-img-icon'
            ), array(
                'color' => $this->cssValue('page_statusbox_border_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '#status_box textarea#message', '.post-status .emoji-toggle .emoji-toggle-icon', '.userTagging-userTagging .bootstrap-tagsinput .twitter-typeahead', '#status_box .form-feed-share a', '.form-feed-temp', '.form-feed-temp:hover', '.form-feed-temp:focus', '.form-feed-temp:visited', '.form-feed-temp:active'
            ), array(
                'color' => $this->cssValue('page_statusbox_message_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.stt-action-item .stt-action-btn .stt-action-icon'
            ), array(
                'color' => $this->cssValue('page_statusbox_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.stt-action-item .stt-action-btn .stt-action-icon'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_icon_background_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.stt-action-item .stt-action-btn .stt-action-icon'
            ), array(
                'border-color' => $this->cssValue('page_statusbox_icon_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'select.post-feed-privacy', '.nice-select.post-feed-privacy'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_privacy_background_color', $cssArray),
                'border-color' => $this->cssValue('page_statusbox_privacy_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'select.post-feed-privacy', '.nice-select.post-feed-privacy > span.current'
            ), array(
                'color' => $this->cssValue('page_statusbox_privacy_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nice-select.post-feed-privacy:after'
            ), array(
                'border-color' => $this->cssValue('page_statusbox_privacy_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nice-select.post-feed-privacy .list'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_privacy_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nice-select.post-feed-privacy .option'
            ), array(
                'color' => $this->cssValue('page_statusbox_privacy_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nice-select.post-feed-privacy .option:hover', '.nice-select.post-feed-privacy .option.focus', '.nice-select.post-feed-privacy .option.selected.focus'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_privacy_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_statusbox_privacy_dropdown_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#status_box a.btn-post_feed'
            ), array(
                'color' => $this->cssValue('page_statusbox_share_color', $cssArray),
                'background-color' => $this->cssValue('page_statusbox_share_background_color', $cssArray),
                'border-color' => $this->cssValue('page_statusbox_share_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.userTagging-userTagging .bootstrap-tagsinput .tag'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_tagpeople_background_color', $cssArray),
                'border-color' => $this->cssValue('page_statusbox_tagpeople_background_color', $cssArray),
                'color' => $this->cssValue('page_statusbox_tagpeople_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.userTagging-userTagging .bootstrap-tagsinput .tt-menu'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_tagpeople_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.userTagging-userTagging .bootstrap-tagsinput .tt-suggestion'
            ), array(
                'color' => $this->cssValue('page_statusbox_tagpeople_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.userTagging-userTagging .bootstrap-tagsinput .tt-suggestion:hover'
            ), array(
                'background-color' => $this->cssValue('page_statusbox_tagpeople_dropdown_active_background_color', $cssArray),
                'color' => $this->cssValue('page_statusbox_tagpeople_dropdown_active_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.form-feed-avatar .user_avatar_name', '.form-feed-avatar .user_avatar_name a'
            ), array(
                'color' => $this->cssValue('page_statusbox_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.post-status-page-content .post-status-page-content-wrap .post-status-back-btn'
            ), array(
                'color' => $this->cssValue('page_statusbox_back_button_color', $cssArray)
            ));

            /* Feed Items --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.feed-entry-item',
                '.activity_feed_content_text .share-content',
                '.activity_item_photo .div_single',
                '.activity_item'
            ), array(
                'background-color' => $this->cssValue('page_feed_item_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item, .feed-entry-item .activity_author'
            ), array(
                'color' => $this->cssValue('page_feed_item_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item .feed_time .feed_time-txt', '.feed-entry-item .feed_time .feed_time-txt.feed_time_history-btn', '.feed-entry-item .feed_time .feed_time-txt .feed_time-icon', '.feed-entry-item .feed_time .feed_time-txt .caret', '.group-header .group-header-cont .group-header-cont-info .group-header-cont-wrapper .group-header-cont-wrapper-info .group-header-cont-wrapper-date'
            ), array(
                'color' => $this->cssValue('page_feed_item_date_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item .feed-option .feed-option-item .feed-option-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_dropdown_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-action .like-action .act-item .act-item-symbol .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_like_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-action .like-action .act-item .act-item-text .act-item-txt'
            ), array(
                'color' => $this->cssValue('page_feed_item_like_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-action .like-action .act-item .act-item-symbol.active .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_like_active_icon_color', $cssArray)
            ));

            /* Feed Comment --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.feed-entry-item .activity_comments'
            ), array(
                'background-color' => $this->cssValue('page_feed_item_comment_background_color', $cssArray),
                'border-color' => $this->cssValue('page_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item .activity_comments', '.comment_view-all .showAllComments', '.comment_view-all .comment_view-icon','.activity_comments .comment_view-all .comment_view-icon', '.activity_comments .comment_view-all .showAllComments'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.post-area-action .post-area-box .post-area-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .comment_lists .comment-item .comment-time', '.activity_comments .comment_lists .comment-item .comment-time a'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_date_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                //'.activity_comments .comment-content-text a',
                '.activity_item_view-more a'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_link_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .like-action .act-item .act-item-symbol .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_like_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .like-action .act-item .act-item-text .act-item-txt'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_like_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .like-action .act-item .act-item-symbol.active .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_like_active_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .btn-submit_comment', '.activity_comments .btn-submit_reply', '.btn-submit_comment.btn-cs .btn-cs-main .btn-icon', '.btn-submit_reply.btn-cs .btn-cs-main .btn-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .btn-submit_comment', '.activity_comments .btn-submit_reply'
            ), array(
                'background-color' => $this->cssValue('page_feed_item_comment_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_feed_item_comment_button_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area', '.activity_comments .post-area-input',
                '.activity-feed-edit-form .post-area', '.activity-feed-edit-form .post-area-input'
            ), array(
                'background-color' => $this->cssValue('page_feed_item_comment_form_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area', '.activity_comments .post-area-input',
                '.activity-feed-edit-form .post-area', '.activity-feed-edit-form .post-area-input'
            ), array(
                'border-color' => $this->cssValue('page_feed_item_comment_form_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area-input',
                '.activity_comments .comment-tool-bar .comment-tool-bar-item .comment-tool-bar-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area-input::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area-input:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .post-area-input::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .commentFormEdit::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .commentFormEdit:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.activity_comments .commentFormEdit::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.cross-icon .comment-option-icon'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_dropdown_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item .edit-post-action .btn-cancel_edit'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_button_cancel_text_color', $cssArray),
                'background-color' => $this->cssValue('page_feed_item_comment_button_cancel_background_color', $cssArray),
                'border-color' => $this->cssValue('page_feed_item_comment_button_cancel_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.feed-entry-item .edit-post-action .btn-submit_edit'
            ), array(
                'color' => $this->cssValue('page_feed_item_comment_button_text_color', $cssArray),
                'background-color' => $this->cssValue('page_feed_item_comment_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_feed_item_comment_button_border_color', $cssArray)
            ));

            /* Comment --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.comment_header_title'
            ), array(
                'color' => $this->cssValue('page_comment_header_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.comment_lists'
            ), array(
                'color' => $this->cssValue('page_comment_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.comment_lists .comment-item .comment-time'
            ), array(
                'color' => $this->cssValue('page_comment_date_color', $cssArray)
            ));
            /*$content .= $this->renderCSS(array(
                '.core_comments .comment-content-text a'
            ), array(
                'color' => $this->cssValue('page_comment_link_color', $cssArray)
            ));*/
            $content .= $this->renderCSS(array(
                '.core_comments .like-action .act-item .act-item-symbol .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_comment_like_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .like-action .act-item .act-item-text .act-item-txt'
            ), array(
                'color' => $this->cssValue('page_comment_like_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .like-action .act-item .act-item-symbol.active .act-item-icon'
            ), array(
                'color' => $this->cssValue('page_comment_like_active_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .btn-submit_comment', '.core_comments .btn-submit_reply'
            ), array(
                'color' => $this->cssValue('page_comment_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .btn-submit_comment', '.core_comments .btn-submit_reply'
            ), array(
                'background-color' => $this->cssValue('page_comment_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_comment_button_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area', '.core_comments .post-area-input'
            ), array(
                'background-color' => $this->cssValue('page_comment_form_background_color', $cssArray),
                'border-color' => $this->cssValue('page_comment_form_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area-input'
            ), array(
                'color' => $this->cssValue('page_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area-input::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area-input:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area-input::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_comment_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.core_comments .post-area-action .post-area-box .post-area-icon'
            ), array(
                'color' => $this->cssValue('page_comment_form_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.comment-item .edit-post-action .btn-cancel_edit'
            ), array(
                'color' => $this->cssValue('page_comment_button_cancel_text_color', $cssArray),
                'background-color' => $this->cssValue('page_comment_button_cancel_background_color', $cssArray),
                'border-color' => $this->cssValue('page_comment_button_cancel_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.comment-item .edit-post-action .btn-submit_edit'
            ), array(
                'color' => $this->cssValue('page_comment_button_text_color', $cssArray),
                'background-color' => $this->cssValue('page_comment_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_comment_button_border_color', $cssArray)
            ));
            /* Header Profile --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.profile-header', '#profile-scroll.profileScrolling .profile-main'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_background_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.profile-header, .profile-user-title .profile-user-name'
            ), array(
                'color' => $this->cssValue('page_profile_header_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.profile_info li a', //'.profile-header a'
            ), array(
                'color' => $this->cssValue('page_profile_header_link_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.profile_info li'
            ), array(
                'color' => $this->cssValue('page_profile_header_info_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn.btn-profile', '.btn-profile'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_profile_header_button_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn.btn-profile, .btn-profile, .btn-dropdown .dropdown .dropdown-btn.btn-profile'
            ), array(
                'color' => $this->cssValue('page_profile_header_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li.current > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li.current > a'
            ), array(
                'border-color' => $this->cssValue('page_profile_header_menu_active_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li:hover > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');

            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li.current > a'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li:hover > a'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.horizontal-menu > li > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_badge_background_color', $cssArray),
                'border-color' => $this->cssValue('page_profile_header_menu_badge_border_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.horizontal-menu > li > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_badge_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li.current > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_badge_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li:hover > a .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_badge_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li.current > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_badge_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu > li:hover > a .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_badge_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li > a'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub > li > a'
            ), array(
                'border-color' => $this->cssValue('page_profile_header_menu_dropdown_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_dropdown_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_menu_dropdown_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_dropdown_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a'
            ), array(
                'color' => $this->cssValue('page_profile_header_menu_dropdown_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub > li > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_dropdown_menu_badge_background_color', $cssArray),
                'border-color' => $this->cssValue('page_profile_header_dropdown_menu_badge_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub > li > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_dropdown_menu_badge_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_dropdown_menu_badge_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter'
            ), array(
                'background-color' => $this->cssValue('page_profile_header_dropdown_menu_badge_active_background_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li.current > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_dropdown_menu_badge_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-menu .horizontal-menu li .horizontal-menu-sub li:hover > a > .badge_counter'
            ), array(
                'color' => $this->cssValue('page_profile_header_dropdown_menu_badge_active_text_color', $cssArray)
            ), '@media (min-width: 992px)');
            $content .= $this->renderCSS(array(
                '.profile-avatar', '.profile-header-box-view #profile-scroll:not(.profileScrolling) .profile-avatar'
            ), array(
                'border-color' => $this->cssValue('page_profile_avatar_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-cover .profile-cover-upload .cover-upload-icon',
                '.profile-avatar .profile-avatar-upload .avatar-upload-icon'
            ), array(
                'color' => $this->cssValue('page_profile_upload_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.profile-cover .profile-cover-upload',
                '.profile-avatar .profile-avatar-upload'
            ), array(
                'background-color' => $this->cssValue('page_profile_upload_icon_background_color', $cssArray),
                'border-color' => $this->cssValue('page_profile_upload_icon_border_color', $cssArray),
            ));

            /* Global Search --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.global-search input#global-search'
            ), array(
                'background-color' => $this->cssValue('page_search_bar_background_color', $cssArray),
                'border-color' => $this->cssValue('page_search_bar_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion'
            ), array(
                'border-color' => $this->cssValue('page_search_bar_suggestion_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search input#global-search', '.global-search .global-search-label .global-search-icon-submit', '.global-search .global-search-label .global-search-icon-cancel'
            ), array(
                'color' => $this->cssValue('page_search_bar_icon_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search input#global-search::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_search_bar_icon_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search input#global-search:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_search_bar_icon_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search input#global-search::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_search_bar_icon_text_color', $cssArray)
            ));
            /* Global Search Suggestion--------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion'
            ), array(
                'background-color' => $this->cssValue('page_search_bar_suggestion_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li.header-filter'
            ), array(
                'background-color' => $this->cssValue('page_search_bar_suggestion_header_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li.header-filter', '.global-search #display-suggestion li.header-filter .header-filter-view-all', '.global-search #display-suggestion li.header-filter.header-filter-see-all a.view-all-result'
            ), array(
                'color' => $this->cssValue('page_search_bar_suggestion_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li > .suggest-right .suggest_name'
            ), array(
                'color' => $this->cssValue('page_search_bar_suggestion_title_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li > .suggest-right .suggest_more_info'
            ), array(
                'color' => $this->cssValue('page_search_bar_suggestion_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li.suggestion-user:hover'
            ), array(
                'background-color' => $this->cssValue('page_search_bar_suggestion_hover_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.global-search #display-suggestion li + li'
            ), array(
                'border-color' => $this->cssValue('page_search_bar_suggestion_item_border_color', $cssArray)
            ));

            /* Block --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.box2 .box_header, .box2 .box_header.mo_breadcrumb'
            ), array(
                'background-color' => $this->cssValue('page_block_header_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2 .box_header .box_header_title', '.box2 .box_header .box_header_title a', '.box2 .box_header.mo_breadcrumb .box_header_title', '.box2 .box_header.mo_breadcrumb .box_header_title a'
            ), array(
                'color' => $this->cssValue('page_block_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2 .box_header .box_header_main', '.box2 .box_header.mo_breadcrumb .box_header_main', '.box2.bar-content-activities .box_header'
            ), array(
                'border-color' => $this->cssValue('page_block_header_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2 .box_header .box_action .btn-header_icon',
                '.box2 .box_header .box_action .btn-header_icon.box-add',
            ), array(
                'color' => $this->cssValue('page_block_header_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2 .box_header .box_action .btn.box-btn', '.user-lists .user-list-item .user-item-action .btn-user-act', '.btn-header_title', '.btn-header_title:hover', '.btn-header_title:active', '.btn-header_title.nice-select.open', '.btn-header_title:focus'
            ), array(
                'background-color' => $this->cssValue('page_block_header_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_block_header_button_border_color', $cssArray),
                'color' => $this->cssValue('page_block_header_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-header_title.btn.btn-cs .btn-cs-main .btn-icon'
            ), array(
                'color' => $this->cssValue('page_block_header_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_action .btn.btn-cs .btn-cs-main .btn-icon', '.profile-action-main .btn.btn-cs .btn-cs-main .btn-icon', '.user-lists .user-list-item .user-item-action .btn-user-act .btn-cs-main .btn-icon', '.qtip_body .btn-user_tip.btn.btn-cs .btn-cs-main .btn-icon'
            ), array(
                'color' => $this->cssValue('page_block_header_button_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2.bar-content-warp .box_content', '.box2.bar-content-warp > .box_menu_more','#photoModal .photo_comments', '#photo_wrapper'
            ), array(
                'background-color' => $this->cssValue('page_block_content_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box2.bar-content-warp .box_content', '.box2 .box_menu_more .box_menu_show_more', '.group-header .group-header-cont .group-header-cont-info .group-header-cont-wrapper .group-header-cont-wrapper-info .group-header-cont-wrapper-name-section .group-header-cont-wrapper-name', '.group-header .group-header-cont .group-header-cont-info .group-header-cont-wrapper .group-header-cont-wrapper-info .group-header-cont-wrapper-name-section .group-header-cont-wrapper-name .profile-user-name-act .profile-user-icon'
            ), array(
                'color' => $this->cssValue('page_block_content_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#photo_close_icon'
            ), array(
                'color' => $this->cssValue('page_block_content_text_color', $cssArray),
                'background-color' => (!empty($cssArray['page_block_content_text_color']['value'])) ? 'rgba(255,255,255,0.1)' : ''
            ));
            $content .= $this->renderCSS(array(
                '.user-summary .user-summary-name'
            ), array(
                'color' => $this->cssValue('page_block_author_name_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.user-summary .user-summary-counter'
            ), array(
                'color' => $this->cssValue('page_block_author_count_color', $cssArray)
            ));

            /* Content Search --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder', '.box_header_search.advanced-search-show-popup .header_search_holder'
            ), array(
                'background-color' => $this->cssValue('page_block_search_header_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder .header_search_title',
            ), array(
                'color' => $this->cssValue('page_block_search_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder input.advanced-search-keyword'
            ), array(
                'color' => $this->cssValue('page_block_search_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder input.advanced-search-keyword::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_block_search_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder input.advanced-search-keyword:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_block_search_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder input.advanced-search-keyword::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_block_search_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_holder .header_search_more .header-search-icon', '.box_header_search .header_search_holder .header_search_btn .header-search-icon'
            ), array(
                'color' => $this->cssValue('page_block_search_header_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_popup'
            ), array(
                'background-color' => $this->cssValue('page_block_search_body_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.box_header_search .header_search_popup .form-group-bottom'
            ), array(
                'background-color' => $this->cssValue('page_block_search_footer_background_color', $cssArray),
                'border-color' => $this->cssValue('page_block_search_footer_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-search_close'
            ), array(
                'background-color' => $this->cssValue('page_block_search_footer_button_close_background_color', $cssArray),
                'border-color' => $this->cssValue('page_block_search_footer_button_close_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-search_close', '.btn-search_close:hover', '.btn-search_close:active', '.btn-search_close:focus'
            ), array(
                'color' => $this->cssValue('page_block_search_footer_button_close_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-search_submit'
            ), array(
                'background-color' => $this->cssValue('page_block_search_footer_button_submit_background_color', $cssArray),
                'border-color' => $this->cssValue('page_block_search_footer_button_submit_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-search_submit', '.btn-search_submit:hover', '.btn-search_submit:active', '.btn-search_submit:focus', '.btn.btn-search_submit .btn-cs-main .btn-icon'
            ), array(
                'color' => $this->cssValue('page_block_search_footer_button_submit_text_color', $cssArray)
            ));

            /* Form Layout --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.form-holder', '.form-holder .form-holder-title'
            ), array(
                'border-color' => $this->cssValue('page_form_group_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-holder .form-holder-title'
            ), array(
                'color' => $this->cssValue('page_form_group_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form', '.create_form .help-block', '.toggle_image_wrap .btn-toggle-image'
            ), array(
                'color' => $this->cssValue('page_form_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-group label'
            ), array(
                'color' => $this->cssValue('page_form_label_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-group label .tip'
            ), array(
                'color' => $this->cssValue('page_form_label_tip_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control', '.multiSelect', '.multiSelectOptions', '.create_form .qq-upload-button', '.share-section #myTabDrop1', '.bootstrap-tagsinput', '.create_form .bootstrap-tagsinput', 'ul.token-input-list'
            ), array(
                'border-color' => $this->cssValue('page_form_input_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control', '.multiSelect', '.multiSelectOptions', '.create_form .qq-upload-button', '.form-control[disabled]', '.form-control[readonly]', 'fieldset[disabled] .form-control', '.share-section #myTabDrop1', '.bootstrap-tagsinput', '.create_form .bootstrap-tagsinput', 'ul.token-input-list', 'ul.token-input-list li input'
            ), array(
                'background-color' => $this->cssValue('page_form_input_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control', '.multiSelect', '.multiSelect:link', '.multiSelect:visited', '.multiSelect:hover', '.multiSelect:active', '.create_form .qq-upload-button .upload-section', '.create_form .qq-upload-button .upload-section i', '.form-control[disabled]', '.form-control[readonly]', 'fieldset[disabled] .form-control', '.create_form .bootstrap-tagsinput input', 'ul.token-input-list', '.share-section #myTabDrop1'
            ), array(
                'color' => $this->cssValue('page_form_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control::-moz-placeholder'
            ), array(
                'color' => $this->cssValue('page_form_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control:-ms-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_form_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.form-control::-webkit-input-placeholder'
            ), array(
                'color' => $this->cssValue('page_form_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'select.form-control'
            ), array(
                'color' => $this->cssValue('page_form_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#myTabDrop1-contents',
                '.nice-select',
                '.nice-select .list'
            ), array(
                'background-color' => $this->cssValue('form_select_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#myTabDrop1-contents li a',
                '.nice-select .option',
                '.nice-select > span.current'
            ), array(
                'color' => $this->cssValue('form_select_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nice-select:after'
            ), array(
                'border-color' => $this->cssValue('form_select_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#myTabDrop1-contents',
                '.nice-select'
            ), array(
                'border-color' => $this->cssValue('form_select_dropdown_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#myTabDrop1-contents li.active a', '#myTabDrop1-contents li a:hover',
                '.nice-select .option:hover', '.nice-select .option.focus', '.nice-select .option.selected.focus'
            ), array(
                'background-color' => $this->cssValue('form_select_dropdown_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '#myTabDrop1-contents li.active a', '#myTabDrop1-contents li a:hover',
                '.nice-select .option:hover', '.nice-select .option.focus', '.nice-select .option.selected.focus'
            ), array(
                'color' => $this->cssValue('form_select_dropdown_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput .label-info', 'ul.token-input-list li.token-input-token'
            ), array(
                'background-color' => $this->cssValue('tagsinput_button_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput .label-info', 'ul.token-input-list li.token-input-token'
            ), array(
                'color' => $this->cssValue('tagsinput_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput .tt-dropdown-menu', '.create_form .bootstrap-tagsinput .tt-menu', 'div.token-input-dropdown', 'div.token-input-dropdown .token-input-result-item'
            ), array(
                'background-color' => $this->cssValue('tagsinput_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput', 'div.token-input-dropdown', 'div.token-input-dropdown .token-input-result-item'
            ), array(
                'color' => $this->cssValue('tagsinput_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput .tt-suggestion:hover', 'div.token-input-dropdown .token-input-result-item.token-input-selected-dropdown-item'
            ), array(
                'background-color' => $this->cssValue('tagsinput_dropdown_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.create_form .bootstrap-tagsinput .tt-suggestion:hover', 'div.token-input-dropdown .token-input-result-item.token-input-selected-dropdown-item'
            ), array(
                'color' => $this->cssValue('tagsinput_dropdown_active_text_color', $cssArray)
            ));

            /* WYSIWYG Html Editor --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                'body .tox .tox-toolbar', 'body .tox .tox-toolbar__overflow', 'body .tox .tox-toolbar__primary', 'body .tox .tox-menu', 'body .tox .tox-statusbar'
            ), array(
                'background-color' => $this->cssValue('wysiwyg_panel_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'body .tox .tox-tbtn', 'body .tox .tox-collection__item', 'body .tox .tox-statusbar a', 'body .tox .tox-statusbar__path-item', 'body .tox .tox-statusbar__wordcount', 'body .tox .tox-statusbar'
            ), array(
                'color' => $this->cssValue('wysiwyg_panel_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'body .tox .tox-tbtn svg', 'body .tox .tox-collection__item-caret svg'
            ), array(
                'fill' => $this->cssValue('wysiwyg_panel_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'body .tox:not([dir="rtl"]) .tox-toolbar__group:not(:last-of-type)'
            ), array(
                'border-color' => $this->cssValue('wysiwyg_panel_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'body .tox .tox-split-button:hover'
            ), array(
                'box-shadow' => $this->cssValue('wysiwyg_panel_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                'body .tox .tox-collection--list .tox-collection__item--active', 'body .tox .tox-tbtn:hover', 'body .tox .tox-collection--toolbar .tox-collection__item--active', 'body .tox .tox-tbtn--enabled', 'body .tox .tox-tbtn--enabled:hover', 'body .tox .tox-collection--list .tox-collection__item--enabled'
            ), array(
                'background-color' => $this->cssValue('wysiwyg_panel_active_background_color', $cssArray)
            ));

            /* Button Default --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-default', '.btn-default.disabled', '.btn-default[disabled]'
            ), array(
                'background-color' => $this->cssValue('page_button_default_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_default_border_color', $cssArray),
                'color' => $this->cssValue('page_button_default_text_color', $cssArray)
            ));

            /* Button Primary --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-primary', '.btn-primary.disabled', '.btn-primary[disabled]', '.btn-primary:hover', '.btn-primary:focus', '.btn-primary:active', '.btn-primary.nice-select.open', '.btn-primary.active'
            ), array(
                'background-color' => $this->cssValue('page_button_primary_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_primary_border_color', $cssArray),
                'color' => $this->cssValue('page_button_primary_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-primary.btn.btn-cs .btn-cs-main .btn-icon'
            ), array(          
                'color' => $this->cssValue('page_button_primary_text_color', $cssArray)
            ));

            /* Button Filled --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-filled', '.btn-filled.disabled', '.btn-filled[disabled]', '.btn-filled:hover', '.btn-filled:focus', '.btn-filled:active', '.btn-filled.nice-select.open', '.btn-filled.active'
            ), array(
                'background-color' => $this->cssValue('page_button_filled_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_filled_border_color', $cssArray),
                'color' => $this->cssValue('page_button_filled_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.btn-filled.btn.btn-cs .btn-cs-main .btn-icon'
            ), array(          
                'color' => $this->cssValue('page_button_filled_text_color', $cssArray)
            ));
            
            
            /* Button Success --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-success', '.btn-success.disabled', '.btn-success[disabled]'
            ), array(
                'background-color' => $this->cssValue('page_button_success_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_success_border_color', $cssArray),
                'color' => $this->cssValue('page_button_success_text_color', $cssArray)
            ));

            /* Button Info --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-info', '.btn-info.disabled', '.btn-info[disabled]'
            ), array(
                'background-color' => $this->cssValue('page_button_info_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_info_border_color', $cssArray),
                'color' => $this->cssValue('page_button_info_text_color', $cssArray)
            ));

            /* Button Warning --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-warning', '.btn-warning.disabled', '.btn-warning[disabled]'
            ), array(
                'background-color' => $this->cssValue('page_button_warning_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_warning_border_color', $cssArray),
                'color' => $this->cssValue('page_button_warning_text_color', $cssArray)
            ));

            /* Button Danger --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.btn-danger', '.btn-danger.disabled', '.btn-danger[disabled]', '.btn-danger:hover', '.btn-danger:focus', '.btn-danger:active', '.btn-danger.nice-select.open', '.btn-danger.active'
            ), array(
                'background-color' => $this->cssValue('page_button_danger_background_color', $cssArray),
                'border-color' => $this->cssValue('page_button_danger_border_color', $cssArray),
                'color' => $this->cssValue('page_button_danger_text_color', $cssArray)
            ));

            /* Post Content --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.post_content'
            ), array(
                'color' => $this->cssValue('content_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.post_content a'
            ), array(
                'color' => $this->cssValue('content_link_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.extra_info'
            ), array(
                'color' => $this->cssValue('content_extra_info_color', $cssArray)
            ));

            /* Blockquote --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.post_body blockquote', '.post_content pre'
            ), array(
                'color' => $this->cssValue('content_text_color', $cssArray),
                'background-color' => $this->cssValue('content_blockquote_background_color', $cssArray),
                'border-color' => $this->cssValue('content_blockquote_border_color', $cssArray)
            ));

            /* Bottom Bar --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.mobile-footer .mobile-footer-btn .mobile-footer-icon'
            ), array(
                'background-color' => $this->cssValue('page_bottom_bar_background_color', $cssArray),
                'border-color' => $this->cssValue('page_bottom_bar_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.mobile-footer .mobile-footer-btn .mobile-footer-icon'
            ), array(
                'color' => $this->cssValue('page_bottom_bar_icons_color', $cssArray)
            ));

            /* Modal Left/Right --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '#leftnav.modal-mobile', '#right.modal-mobile'
            ), array(
                'background-color' => $this->cssValue('page_mobile_modal_bar_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.closeButton .closeButtonIcon'
            ), array(
                'color' => $this->cssValue('page_mobile_modal_bar_icon_color', $cssArray)
            ));

            /* Menu Mobile */
            $content .= $this->renderCSS(array(
                '.mobile-footer-menu'
            ), array(
                'background-color' => $this->cssValue('page_mobile_menu_bottom_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.mobile-footer-menu .mobile-footer-menu-item .mobile-footer-menu-item-icon'
            ), array(
                'color' => $this->cssValue('page_mobile_menu_bottom_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.mobile-footer-menu .mobile-footer-menu-item', '.mobile-footer-menu .mobile-footer-menu-item a'
            ), array(
                'color' => $this->cssValue('page_mobile_menu_bottom_text_color', $cssArray)
            ));

            /* Messages/Notifications Popup --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.notify_content .dropdown-menu.notification_list'
            ), array(
                'background-color' => $this->cssValue('page_notification_popup_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notify_content .dropdown-menu .arr-notify'
            ), array(
                'border-color' => (!empty($cssArray['page_notification_popup_background_color']['value'])) ? 'transparent transparent '.$cssArray['page_notification_popup_background_color']['value'].' transparent' : ''
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notify_top a'
            ), array(
                'color' => $this->cssValue('page_notification_popup_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list .notification-subject'
            ), array(
                'color' => $this->cssValue('page_notification_popup_subject_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list .notification-message'
            ), array(
                'color' => $this->cssValue('page_notification_popup_message_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list .notification-date', '.notification_list .notification-group-list .notification-date a'
            ), array(
                'color' => $this->cssValue('page_notification_popup_date_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list li.notification-group-item'
            ), array(
                'border-color' => $this->cssValue('page_notification_popup_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notify_content .more-notify a'
            ), array(
                'color' => $this->cssValue('page_notification_popup_footer_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notify_content .more-notify'
            ), array(
                'background-color' => $this->cssValue('page_notification_popup_footer_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list .noti_option > a'
            ), array(
                'color' => $this->cssValue('page_notification_popup_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification_list .notification-group-list .noti_option .mark_section.mark_unread .noti_option-icon'
            ), array(
                'color' => $this->cssValue('page_notification_popup_icon_active_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list .notification-group-main.unread'
            ), array(
                'background-color' => $this->cssValue('page_notification_popup_active_background_color', $cssArray)
            ));

            /* Messages/Notifications Page --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.notification-group-list .notification-subject'
            ), array(
                'color' => $this->cssValue('page_notification_subject_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list .notification-message'
            ), array(
                'color' => $this->cssValue('page_notification_message_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list .notification-date', '.notification-group-list .notification-date a'
            ), array(
                'color' => $this->cssValue('page_notification_date_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list li.notification-group-item'
            ), array(
                'border-color' => $this->cssValue('page_notification_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list .noti_option > a'
            ), array(
                'color' => $this->cssValue('page_notification_icon_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.notification-group-list .noti_option .mark_section.mark_unread .noti_option-icon'
            ), array(
                'color' => $this->cssValue('page_notification_icon_active_color', $cssArray)
            ));

            /* Option Dropdown --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.dropdown-menu'
            ), array(
                'background-color' => $this->cssValue('page_option_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.dropdown-menu > li > a'
            ), array(
                'color' => $this->cssValue('page_option_dropdown_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.dropdown-menu > li > a:hover', '.dropdown-menu > li > a:focus'
            ), array(
                'background-color' => $this->cssValue('page_option_dropdown_hover_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.dropdown-menu > li > a:hover', '.dropdown-menu > li > a:focus'
            ), array(
                'color' => $this->cssValue('page_option_dropdown_hover_text_color', $cssArray)
            ));

            /* User Tooltip --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.qtip.qtip-social', '.qtip_body .qtip_user_actions', '.qtip_body .qtip_user_stat .qtip_start_block .qtip_start_left'
            ), array(
                'background-color' => $this->cssValue('page_user_tooltip_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.qtip.qtip-social'
            ), array(
                'border-color' => $this->cssValue('page_user_tooltip_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.qtip_body .qtip_user_avatar .qtip_user_date', '.qtip_body .qtip_user_info', '.qtip_body .qtip_user_title', '.qtip_body .qtip_user_stat', '.qtip_body .qtip_user_stat .qtip_start_block .qtip_start_left'
            ), array(
                'color' => $this->cssValue('page_user_tooltip_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.qtip_body .qtip_user_extra'
            ), array(
                'color' => $this->cssValue('page_user_tooltip_extra_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.qtip_body .btn-user_tip'
            ), array(
                'background-color' => $this->cssValue('page_user_tooltip_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_user_tooltip_button_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.qtip_body .btn-user_tip'
            ), array(
                'color' => $this->cssValue('page_user_tooltip_button_text_color', $cssArray)
            ));

            /* Login Popup --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.login_acc_content .login-popup-group .dropdown-popup-main'
            ), array(
                'background-color' => $this->cssValue('page_login_popup_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_popup_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.login_acc_content .login-popup-group .dropdown-popup-main::before'
            ), array(
                'border-color' => (!empty($cssArray['page_login_popup_border_color']['value'])) ? 'transparent transparent '.$cssArray['page_login_popup_border_color']['value'].' transparent' : ''
            ));
            $content .= $this->renderCSS(array(
                '.popup-login-form', '.dropdown-popup-main .form-group label', '.login_acc_content .login-form .login-form-forgot a', '.login_acc_content .login-form .register_account_form', '.login_acc_content .login-form .register_account_form a'
            ), array(
                'color' => $this->cssValue('page_login_popup_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.login_acc_content .login-popup-group .dropdown-popup-main .form-control'
            ), array(
                'background-color' => $this->cssValue('page_login_popup_input_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_popup_input_border_color', $cssArray),
                'color' => $this->cssValue('page_login_popup_input_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.login_acc_content .login-popup-group .dropdown-popup-main .btn-login'
            ), array(
                'background-color' => $this->cssValue('page_login_popup_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_popup_button_border_color', $cssArray),
                'color' => $this->cssValue('page_login_popup_button_text_color', $cssArray)
            ));

            /* Register Page --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.section-page.registration-page', '.section-page.registration-page .register_main_form'
            ), array(
                'border-color' => $this->cssValue('page_register_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.registration-page .register_main_form',
            ), array(
                'background-color' => $this->cssValue('page_register_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.section-page.registration-page .section-page-header'
            ), array(
                'border-color' => $this->cssValue('page_register_header_border_color', $cssArray),
                'color' => $this->cssValue('page_register_header_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.registration-page .register_main_form', '.registration-page .register_main_form .form-group label'
            ), array(
                'color' => $this->cssValue('page_register_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.registration-page .register_main_form .form-control'
            ), array(
                'background-color' => $this->cssValue('page_register_input_background_color', $cssArray),
                'border-color' => $this->cssValue('page_register_input_border_color', $cssArray),
                'color' => $this->cssValue('page_register_input_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.registration-page .register_main_form #submitFormsignup',
                '.registration-page .register_main_form #step2Submit'
            ), array(
                'background-color' => $this->cssValue('page_register_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_register_button_border_color', $cssArray),
                'color' => $this->cssValue('page_register_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.registration-page', '.close-network-signup .register_social_form'
            ), array(
                'background-color' => $this->cssValue('page_register_social_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.register_social_form', '.close-network-signup .register_social_form'
            ), array(
                'color' => $this->cssValue('page_register_social_text_color', $cssArray)
            ));

            /* Login Page --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.login-page-content'
            ), array(
                'background-color' => $this->cssValue('page_login_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.login-page-content', '.login-page-title', '.login-page-content .form-group label', '.login-page-content .login-form .login-form-forgot a', '.login-page-content .register_social_form', '.login-page-content .login-form .register_account_form', '.login-page-content .login-form .register_account_form a'
            ), array(
                'color' => $this->cssValue('page_login_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.loginPage .login-form .form-control'
            ), array(
                'background-color' => $this->cssValue('page_login_input_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_input_border_color', $cssArray),
                'color' => $this->cssValue('page_login_input_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.loginPage .login-form .btn-login',
            ), array(
                'background-color' => $this->cssValue('page_login_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_login_button_border_color', $cssArray),
                'color' => $this->cssValue('page_login_button_text_color', $cssArray)
            ));

            /* Close Network Sign up --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.signup_intro'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_text_1_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.signup_intro span'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_text_2_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.signup_more'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_text_3_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.user_register_form.close-network-signup'
            ), array(
                'border-color' => $this->cssValue('page_closenetworksignup_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_main_form'
            ), array(
                'background-color' => $this->cssValue('page_closenetworksignup_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.user_register_form.close-network-signup .form-register-title'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_main_form', '.close-network-signup .register_main_form .form-group label'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_main_form .form-control'
            ), array(
                'background-color' => $this->cssValue('page_closenetworksignup_input_background_color', $cssArray),
                'border-color' => $this->cssValue('page_closenetworksignup_input_border_color', $cssArray),
                'color' => $this->cssValue('page_closenetworksignup_input_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_main_form #submitFormsignup', '.close-network-signup .register_main_form #step2Submit',
            ), array(
                'background-color' => $this->cssValue('page_closenetworksignup_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_closenetworksignup_button_border_color', $cssArray),
                'color' => $this->cssValue('page_closenetworksignup_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_social_form'
            ), array(
                'background-color' => $this->cssValue('page_closenetworksignup_social_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.close-network-signup .register_social_form'
            ), array(
                'color' => $this->cssValue('page_closenetworksignup_social_text_color', $cssArray)
            ));

            /* Tag --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.tags li a'
            ), array(
                'background-color' => $this->cssValue('page_tag_background_color', $cssArray),
                'border-color' => $this->cssValue('page_tag_border_color', $cssArray),
                'color' => $this->cssValue('page_tag_text_color', $cssArray)
            ));

            /* Cookies --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.cookies-warning'
            ), array(
                'background-color' => $this->cssValue('page_cookies_background_color', $cssArray),
                'color' => $this->cssValue('page_cookies_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.cookies-warning .btn-cookies'
            ), array(
                'background-color' => $this->cssValue('page_cookies_button_background_color', $cssArray),
                'border-color' => $this->cssValue('page_cookies_button_border_color', $cssArray),
                'color' => $this->cssValue('page_cookies_button_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.cookies-warning .btn-cookies.btn.btn-cs .btn-cs-main .btn-icon'
            ), array(
                'color' => $this->cssValue('page_cookies_button_text_color', $cssArray)
            ));
            /* Tab --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.nav-tabs > li > a', '.core-tab-nav .core-tab-link'
            ), array(
                'background-color' => $this->cssValue('tab_background_color', $cssArray),
                'color' => $this->cssValue('tab_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nav-tabs'
            ), array(
                'border-color' => $this->cssValue('tab_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nav-tabs > li.active > a', '.nav-tabs > li.active > a:hover', '.nav-tabs > li.active > a:focus', '.nav-tabs > li > a:hover', '.nav-tabs > li > a:focus', '.core-tab-nav .core-tab-nav-item.active .core-tab-link'
            ), array(
                'background-color' => $this->cssValue('tab_active_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.nav-tabs > li.active > a', '.nav-tabs > li.active > a:hover', '.nav-tabs > li.active > a:focus', '.nav-tabs > li > a:hover', '.nav-tabs > li > a:focus', '.core-tab-nav .core-tab-nav-item.active .core-tab-link'
            ), array(
                'color' => $this->cssValue('tab_active_text_color', $cssArray)
            ));

            /* Emoji --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.emoji-items-wrap1'
            ), array(
                'background-color' => $this->cssValue('emoji_dropdown_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.emoji-menu'
            ), array(
                'border-color' => $this->cssValue('emoji_dropdown_background_color', $cssArray)
            ));

            /* Table --------------------------------------------------------------------------------------------------------- */
            $content .= $this->renderCSS(array(
                '.table-div',
                '.table'
            ), array(
                'background-color' => $this->cssValue('table_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div .tr-div .td-div', '.table-div .tr-div .th-div'
            ), array(
                'color' => $this->cssValue('table_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div.table-div-head .thead-div .tr-div', '.table-div.table-div-bordered .tr-div', '.table-div.table-div-bordered .tr-div .th-div', '.table-div.table-div-bordered .tr-div .td-div', '.table-div.table-div-condensed .thead-div .tr-div', '.table-div.table-div-condensed .tbody-div .tr-div'
            ), array(
                'border-color' => $this->cssValue('table_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div .tbody-div .tr-div:hover', '.table-div .tbody-div .tr-div:hover .td-div',
                '.table-div.table-div-striped .tbody-div .tr-div:nth-child(2n+1):hover', '.table-div.table-div-striped .tbody-div .tr-div:nth-child(2n+1):hover .td-div'
            ), array(
                'background-color' => $this->cssValue('table_active_background_color', $cssArray),
                'color' => $this->cssValue('table_active_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div.table-div-head-bg .thead-div .tr-div'
            ), array(
                'background-color' => $this->cssValue('table_header_background_color', $cssArray),
                'border-color' => $this->cssValue('table_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div.table-div-head-bg .thead-div .tr-div .th-div'
            ), array(
                'color' => $this->cssValue('table_header_text_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-div.table-div-striped .tbody-div .tr-div:nth-child(2n+1)', '.table-div.table-div-striped .tbody-div .tr-div:nth-child(2n+1) .td-div'
            ), array(
                'background-color' => $this->cssValue('table_highlight_background_color', $cssArray),
                'color' => $this->cssValue('table_highlight_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.table'
            ), array(
                'background-color' => $this->cssValue('table_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table-bordered', '.table > thead > tr > th', '.table > tbody > tr > th', '.table > tfoot > tr > th', '.table > thead > tr > td', '.table > tbody > tr > td', '.table > tfoot > tr > td'
            ), array(
                'border-color' => $this->cssValue('table_border_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.table > thead > tr > th', '.table > tbody > tr > td', '.table > tfoot > tr > td'
            ), array(
                'color' => $this->cssValue('table_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.table-striped > tbody > tr:nth-child(2n+1) > td', '.table-striped > tbody > tr:nth-child(2n+1) > th'
            ), array(
                'background-color' => $this->cssValue('table_highlight_background_color', $cssArray),
                'color' => $this->cssValue('table_highlight_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.table-hover > tbody > tr:hover > td', '.table-hover > tbody > tr:hover > th'
            ), array(
                'background-color' => $this->cssValue('table_active_background_color', $cssArray),
                'color' => $this->cssValue('table_active_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.table > thead > tr > th'
            ), array(
                'background-color' => $this->cssValue('table_header_background_color', $cssArray),
                'color' => $this->cssValue('table_header_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.list-group-item'
            ), array(
                'background-color' => $this->cssValue('list_background_color', $cssArray),
                'color' => $this->cssValue('list_text_color', $cssArray),
                'border-color' => $this->cssValue('list_border_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.list-group-item .material-symbols-outlined'
            ), array(
                'color' => $this->cssValue('list_text_color', $cssArray)
            ));

            $content .= $this->renderCSS(array(
                '.pagination > li > a', '.pagination > li > span',
                '.pagination > .disabled > span', '.pagination > .disabled > span:hover', '.pagination > .disabled > span:focus', '.pagination > .disabled > a', '.pagination > .disabled > a:hover', '.pagination > .disabled > a:focus'
            ), array(
                'color' => $this->cssValue('paginator_text_color', $cssArray),
                'border-color' => $this->cssValue('paginator_border_color', $cssArray),
                'background-color' => $this->cssValue('paginator_background_color', $cssArray)
            ));
            $content .= $this->renderCSS(array(
                '.pagination > .active > a', '.pagination > .active > span', '.pagination > .active > a:hover', '.pagination > .active > span:hover', '.pagination > .active > a:focus', '.pagination > .active > span:focus',
                '.pagination > li > a:hover', '.pagination > li > span:hover', '.pagination > li > a:focus', '.pagination > li > span:focus'
            ), array(
                'color' => $this->cssValue('paginator_current_text_color', $cssArray),
                'border-color' => $this->cssValue('paginator_border_color', $cssArray),
                'background-color' => $this->cssValue('paginator_current_background_color', $cssArray)
            ));

            /* Hook --------------------------------------------------------------------------------------------------------- */
            $controller = new Controller();
            $result = $controller->getEventManager()->dispatch(new CakeEvent('adminThemeSetting.ThemeHelper.theme_setting_css', $this,array(
                'cssArray' => $cssArray
            )));
            if( isset($result->result['settingCssArray']) && is_array($result->result['settingCssArray'])){
                $content .= implode('', $result->result['settingCssArray']);
            }
        }

        return $content;
    }

    private function _theme_setting_dark_mode(){
        return array(
            array('key' => 'page_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_attachment', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_color', 'value' => '#18191a', 'type' => 'color'),
            array('key' => 'page_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_link_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_active_link_color', 'value' => '#98c1df', 'type' => 'color'),
            array('key' => 'page_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_header_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_header_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_header_top_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_header_icons_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_header_icons_active_color', 'value' => '#9fc5e8', 'type' => 'color'),
            array('key' => 'page_header_border_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_user_name_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_user_dropdown_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_user_dropdown_text_color', 'value' => '#bcbcbc', 'type' => 'color'),
            array('key' => 'page_user_dropdown_hover_background_color', 'value' => '#5b5b5b', 'type' => 'color'),
            array('key' => 'page_user_dropdown_hover_text_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_list_item_title_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_list_item_count_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'page_list_item_date_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'page_list_item_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_list_item_link_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_list_item_pin_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_list_item_dropdown_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_icon_active_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_active_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'button_viewmore_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'button_viewmore_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'button_viewmore_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_like_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_like_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_like_icon_active_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_footer_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_footer_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_color', 'value' => '#18191a', 'type' => 'color'),
            array('key' => 'page_footer_border_color', 'value' => 'rgba(224, 224, 224, 0.2)', 'type' => 'color'),
            array('key' => 'page_footer_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_footer_text_link_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_footer_dropdown_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_footer_dropdown_text_link_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'page_navigation_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_navigation_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_navigation_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_navigation_active_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_navigation_active_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_navigation_back_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_navigation_back_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_stickymenu_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_stickymenu_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_border_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_arrow_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_overlay_background_color', 'value' => 'rgba(58, 59, 60, 0.3)', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_close_icon_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_stickymenu_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_category_menu_background_color', 'value' => '#18191a', 'type' => 'color'),
            array('key' => 'page_category_menu_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_active_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'page_category_menu_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_arrow_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_category_menu_arrow_active_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_horizontal_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_horizontal_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_horizontal_active_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'page_horizontal_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_active_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_vertical_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_vertical_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_vertical_active_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'page_vertical_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_active_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_header_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_feed_type_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_feed_type_active_color', 'value' => '#228aff', 'type' => 'color'),
            array('key' => 'page_statusbox_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_statusbox_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_statusbox_message_color', 'value' => '#878b92', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_border_color', 'value' => '#2f3031', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_active_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_share_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_statusbox_share_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_statusbox_share_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_active_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_statusbox_back_button_color', 'value' => '#FAFAFA', 'type' => 'color'),
            array('key' => 'page_feed_item_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_feed_item_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_date_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_dropdown_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_like_icon_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_like_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_like_active_icon_color', 'value' => '#4080ff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_icon_color', 'value' => '#aaa', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_date_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_link_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_icon_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_active_icon_color', 'value' => '#4080ff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_dropdown_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_comment_header_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_comment_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_comment_date_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_comment_like_icon_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_comment_like_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_comment_like_active_icon_color', 'value' => '#228aff', 'type' => 'color'),
            array('key' => 'page_comment_button_text_color', 'value' => '#228aff', 'type' => 'color'),
            array('key' => 'page_comment_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_comment_button_border_color', 'value' => '#228aff', 'type' => 'color'),
            array('key' => 'page_comment_form_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_comment_form_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_comment_form_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_comment_form_icon_color', 'value' => '#aaa', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_profile_header_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_profile_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_profile_header_link_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_profile_header_info_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_profile_header_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_button_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_profile_header_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_active_text_color', 'value' => '#b0b3b8', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_border_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_profile_avatar_border_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_border_color', 'value' => '#626262', 'type' => 'color'),
            array('key' => 'page_search_bar_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_search_bar_border_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_search_bar_icon_text_color', 'value' => '#a6a8ae', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_header_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_title_text_color', 'value' => '#bcbcbc', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_text_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_hover_background_color', 'value' => '#5b5b5b', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_item_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_block_header_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_block_header_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_header_border_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_block_header_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_header_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_block_header_button_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_header_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_header_button_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_content_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_block_content_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_author_name_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_block_author_count_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_search_header_background_color', 'value' => '#18191a', 'type' => 'color'),
            array('key' => 'page_block_search_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_search_header_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_search_body_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_block_search_footer_background_color', 'value' => '#18191a', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_modal_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_modal_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_modal_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_modal_button_close_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_modal_button_close_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_modal_button_close_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_border_color', 'value' => '#f44336', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_text_color', 'value' => '#f44336', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_hover_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_border_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_background_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_form_group_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_form_group_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_form_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_form_label_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_form_label_tip_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_form_input_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_form_input_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_form_input_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'form_select_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'form_select_dropdown_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'form_select_dropdown_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'form_select_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'form_select_dropdown_active_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'tagsinput_button_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'tagsinput_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_active_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_active_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_active_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_button_default_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_button_default_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_default_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_primary_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_button_primary_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_button_primary_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_button_filled_background_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_button_filled_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_button_filled_text_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_button_success_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_success_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_success_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_info_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_info_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_info_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_warning_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_warning_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_button_warning_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_danger_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_button_danger_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_button_danger_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'content_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'content_link_text_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'content_extra_info_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'content_blockquote_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'content_blockquote_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'content_blockquote_border_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_bottom_bar_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_bottom_bar_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_bottom_bar_icons_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_mobile_modal_bar_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_mobile_modal_bar_icon_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_background_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_icon_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_notification_popup_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_notification_popup_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_popup_subject_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_popup_message_text_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_notification_popup_date_text_color', 'value' => '#dddddd', 'type' => 'color'),
            array('key' => 'page_notification_popup_border_color', 'value' => '#3e4042', 'type' => 'color'),
            array('key' => 'page_notification_popup_footer_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'page_notification_popup_footer_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_notification_popup_icon_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_popup_icon_active_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_notification_popup_active_background_color', 'value' => 'rgba(255, 255, 255, 0.1)', 'type' => 'color'),
            array('key' => 'page_notification_subject_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_message_text_color', 'value' => '#e4e6eb', 'type' => 'color'),
            array('key' => 'page_notification_date_text_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'page_notification_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_notification_icon_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_icon_active_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'emoji_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_option_dropdown_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_option_dropdown_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'page_option_dropdown_hover_background_color', 'value' => '#5b5b5b', 'type' => 'color'),
            array('key' => 'page_option_dropdown_hover_text_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_user_tooltip_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'page_user_tooltip_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_user_tooltip_extra_color', 'value' => '#ccc', 'type' => 'color'),
            array('key' => 'page_user_tooltip_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_user_tooltip_button_border_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_user_tooltip_button_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_login_popup_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_input_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_input_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_input_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_button_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_button_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_popup_button_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_header_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_header_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_input_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_input_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_input_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_button_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_button_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_button_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_social_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_register_social_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_input_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_input_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_input_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_button_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_button_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_login_button_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_1_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_2_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_3_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_header_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_border_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_social_background_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_social_text_color', 'value' => '', 'type' => 'color'),
            array('key' => 'page_tag_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_tag_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'page_tag_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'page_cookies_background_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'page_cookies_text_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_cookies_button_background_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_cookies_button_border_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'page_cookies_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'tab_background_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'tab_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'tab_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'tab_active_background_color', 'value' => '#2d88ff', 'type' => 'color'),
            array('key' => 'tab_active_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'table_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'table_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'table_text_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'table_header_background_color', 'value' => '#242f3c', 'type' => 'color'),
            array('key' => 'table_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'table_highlight_background_color', 'value' => '#2e2f2f', 'type' => 'color'),
            array('key' => 'table_highlight_text_color', 'value' => '#a8aab1', 'type' => 'color'),
            array('key' => 'table_active_background_color', 'value' => '#121212', 'type' => 'color'),
            array('key' => 'table_active_text_color', 'value' => '#f2f2f2', 'type' => 'color'),
            array('key' => 'list_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'list_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'list_text_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'list_icon_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'paginator_border_color', 'value' => '#3a3b3c', 'type' => 'color'),
            array('key' => 'paginator_background_color', 'value' => '#242526', 'type' => 'color'),
            array('key' => 'paginator_text_color', 'value' => '#97999d', 'type' => 'color'),
            array('key' => 'paginator_current_text_color', 'value' => '#f3f6f4', 'type' => 'color'),
            array('key' => 'paginator_current_background_color', 'value' => '#2d88ff', 'type' => 'color')
        );
    }

    private function _theme_setting_light_mode(){
        return array(
            array('key' => 'page_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_attachment', 'value' => '', 'type' => 'select'),
            array('key' => 'page_background_color', 'value' => '#ECECEC', 'type' => 'color'),
            array('key' => 'page_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_link_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_active_link_color', 'value' => '#2a6496', 'type' => 'color'),
            array('key' => 'page_border_color', 'value' => '#f7f7f7', 'type' => 'color'),
            array('key' => 'page_header_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_header_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_header_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_header_top_background_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_header_icons_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_header_icons_active_color', 'value' => '#98c1df', 'type' => 'color'),
            array('key' => 'page_header_border_color', 'value' => 'rgba(224, 224, 224, 0.2)', 'type' => 'color'),
            array('key' => 'page_user_name_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_user_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_user_dropdown_text_color', 'value' => '#333333', 'type' => 'color'),
            array('key' => 'page_user_dropdown_hover_background_color', 'value' => 'whitesmoke', 'type' => 'color'),
            array('key' => 'page_user_dropdown_hover_text_color', 'value' => '#262626', 'type' => 'color'),
            array('key' => 'page_list_item_title_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_list_item_count_color', 'value' => '#333333', 'type' => 'color'),
            array('key' => 'page_list_item_date_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_list_item_text_color', 'value' => '#1c1212', 'type' => 'color'),
            array('key' => 'page_list_item_link_color', 'value' => '#000', 'type' => 'color'),
            array('key' => 'page_list_item_pin_icon_color', 'value' => '#a1a1a1', 'type' => 'color'),
            array('key' => 'page_list_item_dropdown_icon_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_icon_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_active_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_icon_active_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_list_item_gridlist_active_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_list_item_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'button_viewmore_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'button_viewmore_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'button_viewmore_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_like_icon_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_like_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_like_icon_active_color', 'value' => '#fb7923', 'type' => 'color'),
            array('key' => 'page_footer_background_image', 'value' => '', 'type' => 'upload_image'),
            array('key' => 'page_footer_background_position', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_repeat', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_size', 'value' => '', 'type' => 'select'),
            array('key' => 'page_footer_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_footer_border_color', 'value' => '#E0E0E0', 'type' => 'color'),
            array('key' => 'page_footer_text_color', 'value' => '#888888', 'type' => 'color'),
            array('key' => 'page_footer_text_link_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_footer_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_footer_dropdown_text_link_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_navigation_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_navigation_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_navigation_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_navigation_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_navigation_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_background_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_border_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_navigation_dropdown_active_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_navigation_back_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_navigation_back_border_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_stickymenu_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_stickymenu_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_background_color', 'value' => '#white', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_stickymenu_count_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_active_background_color', 'value' => '#f0f0f0', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_arrow_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_count_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_overlay_background_color', 'value' => 'rgba(0, 0, 0, 0.5)', 'type' => 'color'),
            array('key' => 'page_stickymenu_dropdown_close_icon_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_stickymenu_icon_color', 'value' => '#212121', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_stickymenu_button_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_category_menu_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_category_menu_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_category_menu_active_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_category_menu_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_border_color', 'value' => '#000', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_border_color', 'value' => '#000', 'type' => 'color'),
            array('key' => 'page_category_menu_counter_active_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_category_menu_arrow_color', 'value' => '#959595', 'type' => 'color'),
            array('key' => 'page_category_menu_arrow_active_color', 'value' => '#959595', 'type' => 'color'),
            array('key' => 'page_horizontal_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_horizontal_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_horizontal_active_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_horizontal_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_active_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_horizontal_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_vertical_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_vertical_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_vertical_active_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_vertical_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_active_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_vertical_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_feed_header_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_feed_type_color', 'value' => '#212121', 'type' => 'color'),
            array('key' => 'page_feed_type_active_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_statusbox_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_statusbox_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_statusbox_message_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_statusbox_icon_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_border_color', 'value' => '#E0E0E0', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_active_background_color', 'value' => '#f6f6f6', 'type' => 'color'),
            array('key' => 'page_statusbox_privacy_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_share_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_statusbox_share_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_statusbox_share_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_active_background_color', 'value' => '#257bba', 'type' => 'color'),
            array('key' => 'page_statusbox_tagpeople_dropdown_active_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_statusbox_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_statusbox_back_button_color', 'value' => '#FAFAFA', 'type' => 'color'),
            array('key' => 'page_feed_item_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_feed_item_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_feed_item_date_text_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_feed_item_dropdown_icon_color', 'value' => '#666666', 'type' => 'color'),
            array('key' => 'page_feed_item_like_icon_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_feed_item_like_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_feed_item_like_active_icon_color', 'value' => '#fb7923', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_icon_color', 'value' => '#1C1B1F', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_date_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_link_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_icon_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_like_active_icon_color', 'value' => '#fb7923', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_border_color', 'value' => '#E0E0E0', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_form_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_dropdown_icon_color', 'value' => '#666666', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_text_color', 'value' => '#333333', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_feed_item_comment_button_cancel_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_comment_header_color', 'value' => '#5F5F5F', 'type' => 'color'),
            array('key' => 'page_comment_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_comment_date_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_comment_like_icon_color', 'value' => '#6e6d6e', 'type' => 'color'),
            array('key' => 'page_comment_like_text_color', 'value' => '#6e6d6e', 'type' => 'color'),
            array('key' => 'page_comment_like_active_icon_color', 'value' => '#fb7923', 'type' => 'color'),
            array('key' => 'page_comment_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_comment_button_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_comment_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_comment_form_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_comment_form_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_comment_form_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_comment_form_icon_color', 'value' => '#1c1b1f', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_comment_button_cancel_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_profile_header_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_profile_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_profile_header_link_text_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_profile_header_info_text_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_profile_header_button_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_profile_header_button_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_button_text_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_active_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_badge_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_active_background_color', 'value' => '#f0f0f0', 'type' => 'color'),
            array('key' => 'page_profile_header_menu_dropdown_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_background_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_background_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_header_dropdown_menu_badge_active_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_profile_avatar_border_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_profile_upload_icon_border_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'page_search_bar_background_color', 'value' => 'rgba(0, 0, 0, 0.2)', 'type' => 'color'),
            array('key' => 'page_search_bar_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_search_bar_icon_text_color', 'value' => '#F2F2F2', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_border_color', 'value' => '#dfdfdf', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_header_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_title_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_text_color', 'value' => '#acacac', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_hover_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_search_bar_suggestion_item_border_color', 'value' => '#dfdfdf', 'type' => 'color'),
            array('key' => 'page_block_header_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_block_header_text_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_block_header_border_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_block_header_icon_color', 'value' => '#212121', 'type' => 'color'),
            array('key' => 'page_block_header_button_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_block_header_button_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_block_header_button_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_block_header_button_icon_color', 'value' => '#4F4F4F', 'type' => 'color'),
            array('key' => 'page_block_content_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_content_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'page_block_author_name_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_block_author_count_color', 'value' => '#888888', 'type' => 'color'),
            array('key' => 'page_block_search_header_background_color', 'value' => '#fafafa', 'type' => 'color'),
            array('key' => 'page_block_search_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_block_search_header_icon_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_block_search_body_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_search_footer_background_color', 'value' => '#fafafa', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_close_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_block_search_footer_button_submit_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_modal_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_modal_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_modal_border_color', 'value' => '#e5e5e5', 'type' => 'color'),
            array('key' => 'page_modal_button_close_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_modal_button_close_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_modal_button_close_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_modal_button_ok_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_background_color', 'value' => '#990000', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_border_color', 'value' => '#990000', 'type' => 'color'),
            array('key' => 'page_modal_button_delete_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'photo_theater_tag_button_hover_text_color', 'value' => '#744700', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'photo_theater_tag_box_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_form_group_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_form_group_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_form_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_form_label_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_form_label_tip_color', 'value' => '#f44336', 'type' => 'color'),
            array('key' => 'page_form_input_border_color', 'value' => '#E0E0E0', 'type' => 'color'),
            array('key' => 'page_form_input_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_form_input_text_color', 'value' => '#9b9b9b', 'type' => 'color'),
            array('key' => 'form_select_dropdown_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'form_select_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'form_select_dropdown_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'form_select_dropdown_active_background_color', 'value' => '#f6f6f6', 'type' => 'color'),
            array('key' => 'form_select_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'tagsinput_button_background_color', 'value' => '#979797', 'type' => 'color'),
            array('key' => 'tagsinput_button_text_color', 'value' => '#ffffff', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_active_background_color', 'value' => '#f6f6f6', 'type' => 'color'),
            array('key' => 'tagsinput_dropdown_active_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'wysiwyg_panel_active_background_color', 'value' => '#dee0e2', 'type' => 'color'),
            array('key' => 'page_button_default_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_button_default_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_button_default_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_button_primary_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_button_primary_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_button_primary_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_button_filled_background_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_button_filled_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_button_filled_text_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_button_success_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_button_success_border_color', 'value' => '#00b901', 'type' => 'color'),
            array('key' => 'page_button_success_text_color', 'value' => '#00b901', 'type' => 'color'),
            array('key' => 'page_button_info_background_color', 'value' => '#6fa8dc', 'type' => 'color'),
            array('key' => 'page_button_info_border_color', 'value' => '#6fa8dc', 'type' => 'color'),
            array('key' => 'page_button_info_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_button_warning_background_color', 'value' => '#f1c232', 'type' => 'color'),
            array('key' => 'page_button_warning_border_color', 'value' => '#f1c232', 'type' => 'color'),
            array('key' => 'page_button_warning_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_button_danger_background_color', 'value' => '#f44336', 'type' => 'color'),
            array('key' => 'page_button_danger_border_color', 'value' => '#f44336', 'type' => 'color'),
            array('key' => 'page_button_danger_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'content_text_color', 'value' => '#4f4f4f', 'type' => 'color'),
            array('key' => 'content_link_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'content_extra_info_color', 'value' => '#999999', 'type' => 'color'),
            array('key' => 'content_blockquote_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'content_blockquote_background_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'content_blockquote_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_bottom_bar_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_bottom_bar_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_bottom_bar_icons_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_mobile_modal_bar_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_mobile_modal_bar_icon_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_background_color', 'value' => '#fff', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_icon_color', 'value' => '#1C1B1F', 'type' => 'color'),
            array('key' => 'page_mobile_menu_bottom_text_color', 'value' => '#828282', 'type' => 'color'),
            array('key' => 'page_notification_popup_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_notification_popup_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_subject_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_message_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_date_text_color', 'value' => '#999999', 'type' => 'color'),
            array('key' => 'page_notification_popup_border_color', 'value' => '#dfdfdf', 'type' => 'color'),
            array('key' => 'page_notification_popup_footer_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_footer_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'page_notification_popup_icon_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_icon_active_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_popup_active_background_color', 'value' => '#e5e5e5', 'type' => 'color'),
            array('key' => 'page_notification_subject_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_message_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_date_text_color', 'value' => '#999999', 'type' => 'color'),
            array('key' => 'page_notification_border_color', 'value' => '#dfdfdf', 'type' => 'color'),
            array('key' => 'page_notification_icon_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_notification_icon_active_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'emoji_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_option_dropdown_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_option_dropdown_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_option_dropdown_hover_background_color', 'value' => 'whitesmoke', 'type' => 'color'),
            array('key' => 'page_option_dropdown_hover_text_color', 'value' => '#262626', 'type' => 'color'),
            array('key' => 'page_user_tooltip_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_user_tooltip_text_color', 'value' => '#000', 'type' => 'color'),
            array('key' => 'page_user_tooltip_extra_color', 'value' => '#828282', 'type' => 'color'),  
            array('key' => 'page_user_tooltip_button_background_color', 'value' => 'transparent', 'type' => 'color'),
            array('key' => 'page_user_tooltip_button_border_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_user_tooltip_button_text_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_login_popup_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_login_popup_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_login_popup_border_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_login_popup_input_border_color', 'value' => '#979797', 'type' => 'color'),
            array('key' => 'page_login_popup_input_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_login_popup_input_text_color', 'value' => '#9b9b9b', 'type' => 'color'),
            array('key' => 'page_login_popup_button_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_login_popup_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_login_popup_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_register_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_register_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_register_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_register_header_border_color', 'value' => '#eeeeee', 'type' => 'color'),
            array('key' => 'page_register_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_register_input_border_color', 'value' => '#979797', 'type' => 'color'),
            array('key' => 'page_register_input_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_register_input_text_color', 'value' => '#9b9b9b', 'type' => 'color'),
            array('key' => 'page_register_button_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_register_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_register_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_register_social_background_color', 'value' => '#f4f4f4', 'type' => 'color'),
            array('key' => 'page_register_social_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_login_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_login_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_login_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_login_input_border_color', 'value' => '#979797', 'type' => 'color'),
            array('key' => 'page_login_input_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_login_input_text_color', 'value' => '#9b9b9b', 'type' => 'color'),
            array('key' => 'page_login_button_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_login_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_login_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_1_color', 'value' => '#3e3e3e', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_2_color', 'value' => '#5a9e0b', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_3_color', 'value' => '#4a4a4a', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_header_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_border_color', 'value' => '#979797', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_input_text_color', 'value' => '#9b9b9b', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_border_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_button_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_social_background_color', 'value' => '#f4f4f4', 'type' => 'color'),
            array('key' => 'page_closenetworksignup_social_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_tag_background_color', 'value' => '#f4f4f4', 'type' => 'color'),
            array('key' => 'page_tag_border_color', 'value' => '#c5c5c5', 'type' => 'color'),
            array('key' => 'page_tag_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'page_cookies_background_color', 'value' => '#063567', 'type' => 'color'),
            array('key' => 'page_cookies_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_cookies_button_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'page_cookies_button_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'page_cookies_button_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'tab_background_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'tab_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'tab_border_color', 'value' => '#cccccc', 'type' => 'color'),
            array('key' => 'tab_active_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'tab_active_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'table_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'table_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'table_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'table_header_background_color', 'value' => '#00477b', 'type' => 'color'),
            array('key' => 'table_header_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'table_highlight_background_color', 'value' => '#f1f1f1', 'type' => 'color'),
            array('key' => 'table_highlight_text_color', 'value' => '#444444', 'type' => 'color'),
            array('key' => 'table_active_background_color', 'value' => '#ececec', 'type' => 'color'),
            array('key' => 'table_active_text_color', 'value' => '#5b5b5b', 'type' => 'color'),
            array('key' => 'list_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'list_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'list_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'list_icon_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'paginator_border_color', 'value' => '#e0e0e0', 'type' => 'color'),
            array('key' => 'paginator_background_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'paginator_text_color', 'value' => 'black', 'type' => 'color'),
            array('key' => 'paginator_current_text_color', 'value' => 'white', 'type' => 'color'),
            array('key' => 'paginator_current_background_color', 'value' => '#00477b', 'type' => 'color')
        );
    }

    public function get_theme_setting_default_css($appearance){
        if($appearance == 'dark'){
            return $this->_theme_setting_dark_mode();
        }else if($appearance == 'light'){
            return $this->_theme_setting_light_mode();
        }
        return array();
    }

    public function get_theme_setting_form_data($data){
        $result = array();
        if(!empty($data)){
            foreach ($data As $item){
                $result[$item['key']] = array(
                    'value' => $item['value'],
                    'type' => $item['type']
                );
            }
        }
        return $result;
    }
}